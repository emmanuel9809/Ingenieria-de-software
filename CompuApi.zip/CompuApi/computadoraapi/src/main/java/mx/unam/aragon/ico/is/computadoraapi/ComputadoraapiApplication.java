package mx.unam.aragon.ico.is.computadoraapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComputadoraapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComputadoraapiApplication.class, args);
	}

}
